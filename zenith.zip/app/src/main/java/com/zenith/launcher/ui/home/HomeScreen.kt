package com.zenith.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.zenith.launcher.data.model.WidgetIds
import com.zenith.launcher.ui.home.components.AddBacklogDialog
import com.zenith.launcher.ui.home.components.AddLibraryDialog
import com.zenith.launcher.ui.home.components.AddTodoDialog
import com.zenith.launcher.ui.home.components.AppDrawerOverlay
import com.zenith.launcher.ui.home.components.AppShortcutsWidget
import com.zenith.launcher.ui.home.components.BacklogWidget
import com.zenith.launcher.ui.home.components.DeadlinesWidget
import com.zenith.launcher.ui.home.components.FocusModeToggle
import com.zenith.launcher.ui.home.components.GreetingHeader
import com.zenith.launcher.ui.home.components.GridDragDropState
import com.zenith.launcher.ui.home.components.HomeBackground
import com.zenith.launcher.ui.home.components.TargetsWidget
import com.zenith.launcher.ui.home.components.LibraryWidget
import com.zenith.launcher.ui.home.components.PomodoroWidget
import com.zenith.launcher.ui.home.components.SystemStatusWidget
import com.zenith.launcher.ui.home.components.TodoWidget
import com.zenith.launcher.ui.home.components.gridDragToReorder
import com.zenith.launcher.ui.home.components.rememberGridDragDropState
import com.zenith.launcher.ui.home.components.reportColumnBounds
import com.zenith.launcher.util.SystemActionsHelper
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/** How many columns the widget grid lays widgets out into - matches the reference design. */
private const val GRID_COLUMN_COUNT = 3

/** Cumulative horizontal drag (px) needed before a right-edge swipe counts as "open the drawer". */
private const val DRAWER_SWIPE_OPEN_THRESHOLD_PX = 60f

/**
 * Width of the invisible left/right edge-swipe strips - deliberately kept equal to the grid Row's
 * own outer horizontal padding (see the Row in [HomeScreen]) so the strips live entirely within
 * that visual margin and never overlap a widget's actual touch area.
 */
private val EDGE_SWIPE_STRIP_WIDTH = 12.dp

/**
 * Only these widgets stay usable while a Pomodoro focus session is running - every other widget
 * is blurred *and* has its touches blocked (see the grid loop in [HomeScreen]), the Settings
 * gear and the App Drawer edge-swipe are disabled, and the grid can't be rearranged. The lock
 * lifts the moment the session is completed, paused, or reset (i.e. whenever the Pomodoro
 * widget itself reports back that it's no longer running).
 */
private val POMODORO_ACCESSIBLE_WIDGETS = setOf(
    WidgetIds.POMODORO,
    WidgetIds.TODO,
    WidgetIds.BACKLOG,
    WidgetIds.LIBRARY
)

/**
 * The launcher's home screen: a live clock + greeting header, a hold-and-drag reorderable
 * 3-column widget grid, and a right-edge swipe (right-to-left) that opens the App Drawer as its
 * own full-screen area (see [AppDrawerOverlay]) - installed apps never live inside this grid.
 */
@Composable
fun HomeScreen(viewModel: HomeViewModel, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsState()
    var showAddTodoDialog by remember { mutableStateOf(false) }
    var showAddBacklogDialog by remember { mutableStateOf(false) }
    var showAddLibraryDialog by remember { mutableStateOf(false) }
    var isDrawerOpen by remember { mutableStateOf(false) }
    var isPomodoroRunning by remember { mutableStateOf(false) }
    var showFocusEntryPause by remember { mutableStateOf(false) }
    var showFocusExitPause by remember { mutableStateOf(false) }
    var isPomodoroProtectionActive by remember { mutableStateOf(false) }
    var pomodoroPauseSeconds by remember { mutableStateOf(0) }
    var pomodoroPauseMessage by remember { mutableStateOf("") }
    var resizePreviewDelta by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }

    // Protect only deliberate focus/reflection windows, not the whole Pomodoro. This keeps the
    // Android system surface available during ordinary study time while closing the escape hatch
    // during moments when Zenith is asking the student to pause and choose deliberately.
    val systemUiProtected = state.isFocusModeActive || showFocusEntryPause || showFocusExitPause ||
        state.distractionPauseSeconds > 0 || isPomodoroProtectionActive
    val window = (context as? android.app.Activity)?.window
    LaunchedEffect(systemUiProtected, state.attentionProtectionMode, window) {
        window?.let {
            SystemActionsHelper.setAttentionProtection(
                window = it,
                context = context,
                mode = state.attentionProtectionMode,
                protected = systemUiProtected
            )
        }
    }

    val phoneLayout = LocalConfiguration.current.screenWidthDp < 600
    // Phones use one comfortable reading column; tablets keep the existing three-column layout.
    // The saved three-column arrangement is never rewritten merely because a phone is displaying it.
    val visibleColumns = remember(state.widgetColumns, state.widgetVisibility, phoneLayout) {
        val filtered = state.widgetColumns.map { column ->
            column.filter { id -> isWidgetEnabled(id, state.widgetVisibility) }
        }
        if (phoneLayout) listOf(filtered.flatten()) else filtered
    }
    val dragState = rememberGridDragDropState(columns = visibleColumns) { id, toColumn, toIndex ->
        if (!phoneLayout) viewModel.moveWidget(id, toColumn, toIndex)
    }

    // A launcher's onResume fires both on a cold "go to Home" and - if this was the last
    // foreground app before the phone locked - the moment the user unlocks again, so replaying
    // a quick fade + scale-in here on every resume covers "widgets loading in after unlock"
    // without needing to hook into ACTION_USER_PRESENT separately.
    var resumeTrigger by remember { mutableStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                resumeTrigger++
                // Package install/uninstall and system app-info screens return Home through this
                // path; refreshing here makes the drawer, shortcuts and icon pack resolve at
                // once instead of retaining a stale process-local list.
                viewModel.loadApps()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val contentAlpha = remember { Animatable(0f) }
    val contentScale = remember { Animatable(0.96f) }
    LaunchedEffect(resumeTrigger) {
        contentAlpha.snapTo(0f)
        contentScale.snapTo(0.96f)
        launch { contentAlpha.animateTo(1f, tween(420)) }
        launch { contentScale.animateTo(1f, tween(420, easing = FastOutSlowInEasing)) }
    }

    // System back closes the app drawer if it's open, otherwise exits widget-rearranging mode if
    // that's active - both take priority over the launcher's normal "swallow back" behaviour.
    BackHandler(enabled = isDrawerOpen) { isDrawerOpen = false }
    BackHandler(enabled = !isDrawerOpen && dragState.editMode) { dragState.exitEditMode() }
    BackHandler(enabled = showFocusEntryPause || showFocusExitPause) { /* The reflection completes automatically. */ }

    Box(modifier = Modifier.fillMaxSize()) {
        HomeBackground(background = state.background)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .graphicsLayer {
                    alpha = contentAlpha.value
                    scaleX = contentScale.value
                    scaleY = contentScale.value
                }
                // Attach this to the full Home surface rather than only the header. Child
                // widgets keep their own gestures; a double tap on any unused Home space locks.
                .then(
                    if (state.lockOnDoubleTap) {
                        Modifier.pointerInput(state.lockOnDoubleTap) {
                            detectTapGestures(onDoubleTap = { SystemActionsHelper.lockScreen(context) })
                        }
                    } else Modifier
                )
        ) {
            GreetingHeader(
                greeting = state.greeting,
                // The Settings gear is one of the things a running Pomodoro session locks out -
                // disabled (not hidden) so it's clear why it's unresponsive, and the header
                // itself is left crisp rather than blurred like the rest of the locked screen.
                onSettingsClick = onOpenSettings,
                settingsEnabled = !isPomodoroRunning,
                overPhotoBackground = state.background.imageUri != null,
                lockOnDoubleTap = state.lockOnDoubleTap
            )

            Box(modifier = Modifier.weight(1f)) {
                if (visibleColumns.all { it.isEmpty() }) {
                    Text(
                        text = "Your Home is ready. Open Settings to enable the widgets you want.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = androidx.compose.ui.graphics.Color.White,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
                            .clickable(onClick = onOpenSettings)
                            .padding(horizontal = 24.dp, vertical = 18.dp)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = if (phoneLayout) 8.dp else 12.dp, vertical = 8.dp)
                        // While rearranging, a tap on empty grid space (i.e. not consumed by any
                        // widget's own drag/click handling) finishes editing - the same as
                        // tapping empty space on the stock Android home screen.
                        .then(
                            if (dragState.editMode) {
                                Modifier.pointerInput(Unit) { detectTapGestures { dragState.exitEditMode() } }
                            } else {
                                Modifier
                            }
                        ),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (columnIndex in 0 until if (phoneLayout) 1 else GRID_COLUMN_COUNT) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .reportColumnBounds(dragState, columnIndex),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            visibleColumns.getOrNull(columnIndex)?.forEach { id ->
                                // Explicit key by widget id (not just position) so a widget's own
                                // local state - e.g. a running Pomodoro timer - stays attached to
                                // that widget as it moves, instead of Compose reattaching state to
                                // whatever now sits in the old slot.
                                key(id) {
                                    val isDragging = dragState.isDragging(id)
                                    val isLockedByPomodoro = isPomodoroRunning && id !in POMODORO_ACCESSIBLE_WIDGETS
                                    val baseHeight = state.widgetHeights[id] ?: WidgetIds.DEFAULT_HEIGHTS[id] ?: state.widgetSizes[id]?.minHeightDp ?: 160
                                    val displayedHeight = (baseHeight + (resizePreviewDelta[id] ?: 0)).coerceIn(88, 600)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            // The real widget is only ever hidden, never moved by
                                            // hand, while its ghost (below) does the floating -
                                            // see GridDragDropState's class doc for why.
                                            .alpha(if (isDragging) 0f else 1f)
                                            // The whole grid is frozen in place for the duration of
                                            // a Pomodoro session - not just the locked-out widgets -
                                            // so the layout can't shift under the three that remain
                                            // usable.
                                            .then(
                                                if (isPomodoroRunning) Modifier else Modifier.gridDragToReorder(dragState, id)
                                            )
                                            .then(if (isLockedByPomodoro) Modifier.blur(10.dp) else Modifier)
                                            .height(displayedHeight.dp)
                                    ) {
                                        WidgetForId(
                                            id = id,
                                            state = state,
                                            viewModel = viewModel,
                                            onShowAddTodo = { showAddTodoDialog = true },
                                            onShowAddBacklog = { showAddBacklogDialog = true },
                                            onShowAddLibrary = { showAddLibraryDialog = true },
                                            onFocusToggle = {
                                                if (state.isFocusModeActive) {
                                                    showFocusExitPause = true
                                                } else if (!showFocusEntryPause) {
                                                    showFocusEntryPause = true
                                                }
                                            },
                                            onPomodoroRunningChanged = { isPomodoroRunning = it },
                                            onPomodoroProtectionChanged = { isPomodoroProtectionActive = it },
                                            onPomodoroPauseChanged = { active, seconds, message ->
                                                pomodoroPauseSeconds = if (active) seconds else 0
                                                pomodoroPauseMessage = if (active) message else ""
                                            }
                                        )
                                        if (isLockedByPomodoro) {
                                            // Keep locked widgets recognizable but visually subordinate:
                                            // the stronger blur makes the active Pomodoro surface feel like
                                            // the only thing that matters, while the soft veil preserves
                                            // enough context to remind the student that the rest still exists.
                                            Box(
                                                modifier = Modifier
                                                    .matchParentSize()
                                                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.12f))
                                                    .pointerInput(id) { detectTapGestures { } }
                                            )
                                        }
                                        if (dragState.editMode) {
                                            WidgetResizeGrip(
                                                onHeightPreview = { delta ->
                                                    resizePreviewDelta = resizePreviewDelta + (id to delta)
                                                },
                                                onHeightChangeEnd = { totalDelta ->
                                                    if (totalDelta != 0) viewModel.adjustWidgetHeight(id, totalDelta)
                                                    resizePreviewDelta = resizePreviewDelta - id
                                                },
                                                modifier = Modifier.align(Alignment.BottomEnd)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                DragGhostOverlay(dragState = dragState) { id ->
                    WidgetForId(
                        id = id,
                        state = state,
                        viewModel = viewModel,
                        onShowAddTodo = {},
                        onShowAddBacklog = {},
                        onShowAddLibrary = {},
                        onFocusToggle = {},
                        onPomodoroRunningChanged = {}
                    )
                }

                EditModeDonePill(
                    visible = dragState.editMode,
                    onDone = { dragState.exitEditMode() },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                )
            }
        }

        // Invisible strip along the right edge of the screen: swiping right-to-left starting
        // from here opens the App Drawer, mirroring how edge swipes work elsewhere on Android
        // without hijacking horizontal gestures used by widgets in the middle of the screen.
        // Sized to sit exactly within the grid Row's own outer padding (see the Row above) so it
        // never overlaps a widget's actual touch area - previously it was wider than that margin
        // and could steal the very first pixels of a drag starting from the rightmost column.
        // It's also fully disabled while rearranging, so it can never compete with a drag at all -
        // and disabled for the duration of a running Pomodoro session, since the App Drawer isn't
        // one of the widgets a session leaves accessible.
        if (!isDrawerOpen && !dragState.editMode && !isPomodoroRunning) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(EDGE_SWIPE_STRIP_WIDTH)
                    .pointerInput(Unit) {
                        var accumulated = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { accumulated = 0f },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                accumulated += dragAmount
                                if (accumulated < -DRAWER_SWIPE_OPEN_THRESHOLD_PX) isDrawerOpen = true
                            }
                        )
                    }
            )
        }

        AnimatedVisibility(
            visible = isDrawerOpen,
            enter = slideInHorizontally(initialOffsetX = { fullWidth -> fullWidth }),
            exit = slideOutHorizontally(targetOffsetX = { fullWidth -> fullWidth }),
            modifier = Modifier.fillMaxSize()
        ) {
            AppDrawerOverlay(
                apps = state.apps,
                categories = state.appCategories,
                categoryTypes = state.appCategoryTypes,
                background = state.background,
                onLaunch = { app -> viewModel.launchApp(app); isDrawerOpen = false },
                onDismiss = { isDrawerOpen = false },
                onUninstall = viewModel::uninstallApp,
                canUninstall = viewModel::canUninstall,
                onOpenAppInfo = viewModel::openAppInfo,
                onSetCategory = viewModel::setAppCategory,
                onPinShortcut = viewModel::addAppShortcut,
                focusAllowedPackages = state.focusAllowedApps,
                distractionPackages = state.distractionApps,
                onToggleFocusAllowed = viewModel::toggleFocusAllowedApp,
                onToggleDistraction = viewModel::toggleDistractionApp
            )
        }

        if (showFocusEntryPause) {
            FocusModeEntryPause(onFinished = {
                showFocusEntryPause = false
                viewModel.toggleFocusMode()
            })
        }

        if (showFocusExitPause) {
            FocusModeExitPause(onFinished = {
                showFocusExitPause = false
                viewModel.toggleFocusMode()
            })
        }

        if (pomodoroPauseSeconds > 0) {
            PomodoroReflectionPause(
                secondsLeft = pomodoroPauseSeconds,
                message = pomodoroPauseMessage
            )
        }

        state.distractionPauseApp?.let {
            DistractionLaunchPause(
                secondsLeft = state.distractionPauseSeconds,
                message = state.distractionPauseMessage
            )
        }
    }

    if (showAddTodoDialog) {
        AddTodoDialog(
            onDismiss = { showAddTodoDialog = false },
            onConfirm = { text -> viewModel.addTodo(text); showAddTodoDialog = false }
        )
    }
    if (showAddBacklogDialog) {
        AddBacklogDialog(
            onDismiss = { showAddBacklogDialog = false },
            onConfirm = { subject, itemName, urgency ->
                viewModel.addBacklogItem(subject, itemName, urgency)
                showAddBacklogDialog = false
            }
        )
    }
    if (showAddLibraryDialog) {
        AddLibraryDialog(
            onDismiss = { showAddLibraryDialog = false },
            onConfirm = { title, uri -> viewModel.addLibraryLink(title, uri); showAddLibraryDialog = false }
        )
    }
}

/** Drag the diagonal corner grip to resize a widget; no preset-size buttons are needed. */
@Composable
private fun WidgetResizeGrip(
    onHeightPreview: (Int) -> Unit,
    onHeightChangeEnd: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    Box(
        modifier = modifier
            .size(44.dp)
            .clip(RoundedCornerShape(topStart = 14.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.88f))
            .pointerInput(Unit) {
                var accumulatedY = 0f
                detectDragGestures(
                    onDragStart = { accumulatedY = 0f },
                    onDragEnd = {
                        val totalDp = with(density) { (accumulatedY / density.density).toInt() }
                        val committedDp = (totalDp / 24) * 24
                        onHeightChangeEnd(committedDp)
                        accumulatedY = 0f
                    },
                    onDragCancel = {
                        onHeightChangeEnd(0)
                        accumulatedY = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        accumulatedY += dragAmount.y
                        val previewDp = with(density) { (accumulatedY / density.density).toInt() }
                        onHeightPreview(previewDp)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text("↕", color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

/** A short, non-interactive reflection shown when Zenith intercepts a distraction launch. */
@Composable
private fun DistractionLaunchPause(secondsLeft: Int, message: String) {
    ReflectionPauseSurface(
        title = "Distractions",
        secondsLeft = secondsLeft,
        message = message,
        ringSize = 190.dp
    )
}

/** The same full-screen reflection treatment used by the other deliberate pause moments. */
@Composable
private fun PomodoroReflectionPause(secondsLeft: Int, message: String) {
    ReflectionPauseSurface(
        title = "Pomodoro",
        secondsLeft = secondsLeft,
        message = message,
        ringSize = 210.dp
    )
}

@Composable
private fun ReflectionPauseSurface(
    title: String,
    secondsLeft: Int,
    message: String,
    ringSize: Dp
) {
    val breathing = rememberInfiniteTransition(label = "reflectionPauseBreath-$title")
    val ringScale by breathing.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            tween(2800, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "reflectionPauseBreathScale-$title"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.82f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(ringSize)
                .graphicsLayer { scaleX = ringScale; scaleY = ringScale }
                .clip(RoundedCornerShape(ringSize / 2))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        )
        Column(
            modifier = Modifier.padding(horizontal = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(
                message,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Text(
                secondsLeft.coerceAtLeast(0).toString(),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * A deliberately non-interactive pause before entering Focus Mode. It is not a confirmation:
 * after five seconds the mode starts automatically, giving the user a small moment to notice
 * what they are choosing to give their attention to.
 */
@Composable
private fun FocusModeEntryPause(onFinished: () -> Unit) {
    var secondsLeft by remember { mutableStateOf(5) }
    val messages = ZenithCopy.focusModeEntry
    val breathing = rememberInfiniteTransition(label = "focusEntryBreath")
    val ringScale by breathing.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            tween(2600, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "focusEntryBreathScale"
    )
    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.78f))
            // Consume taps so this stays a reflection rather than an accidental confirmation.
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .graphicsLayer { scaleX = ringScale; scaleY = ringScale }
                .clip(RoundedCornerShape(100.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f))
        )
        Column(
            modifier = Modifier.padding(horizontal = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("A moment before focus", style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(
                messages[(5 - secondsLeft).coerceIn(0, messages.lastIndex)],
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Text(
                "Starting in $secondsLeft s",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * A deliberately non-interactive pause before ending Focus Mode. It is not a confirmation:
 * after a short breathing interval the mode is switched off automatically.
 */
@Composable
private fun FocusModeExitPause(onFinished: () -> Unit) {
    var secondsLeft by remember { mutableStateOf(18) }
    val messages = listOf(
        "Give yourself a moment before changing direction.",
        "Notice what you completed before you leave this space.",
        "Take one slow breath and let the next choice be deliberate.",
        "You can leave focus — just notice the choice first."
    )
    val breathing = rememberInfiniteTransition(label = "focusExitBreath")
    val ringScale by breathing.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(3500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "focusExitBreathScale"
    )
    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft--
        }
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.78f))
            // Consume taps so this stays a reflection rather than an accidental confirmation.
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(210.dp)
                .graphicsLayer { scaleX = ringScale; scaleY = ringScale }
                .clip(RoundedCornerShape(105.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
        )
        Column(
            modifier = Modifier.padding(horizontal = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Pause before leaving Focus Mode", style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(
                messages[(18 - secondsLeft) / 5 % messages.size],
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.9f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Text(
                "Exhale slowly · continuing in $secondsLeft s",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Focus Mode will turn off automatically. No response is needed.",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

/**
 * The single floating "ghost" copy of whichever widget is currently being dragged (see
 * [GridDragDropState]'s class doc for why this exists). Positioned directly from
 * [GridDragDropState.dragPointerRoot] with no dependency on the grid's own layout, so it can
 * never jitter from a layout-timing race the way an in-place offset could.
 */
@Composable
private fun DragGhostOverlay(dragState: GridDragDropState, content: @Composable (id: String) -> Unit) {
    val id = dragState.draggingId ?: return
    val size = dragState.draggingItemSize ?: return
    val density = LocalDensity.current

    val widthDp = with(density) { size.width.toDp() }
    val heightDp = with(density) { size.height.toDp() }
    val leftPx = dragState.dragPointerRoot.x - size.width / 2f
    val topPx = dragState.dragPointerRoot.y - size.height / 2f

    Box(
        modifier = Modifier
            .offset { IntOffset(leftPx.roundToInt(), topPx.roundToInt()) }
            .width(widthDp)
            .height(heightDp)
            .graphicsLayer {
                scaleX = 1.05f
                scaleY = 1.05f
                shadowElevation = 24f
            }
            .zIndex(2f)
            .alpha(0.96f)
    ) {
        content(id)
    }
}

/** Small floating pill shown at the bottom of the grid while rearranging - tap to finish. */
@Composable
private fun EditModeDonePill(visible: Boolean, onDone: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = visible, modifier = modifier) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.primary)
                .clickable(onClick = onDone)
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Done rearranging",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}

/** Whether widget [id] is currently toggled on in Settings > Widgets. */
private fun isWidgetEnabled(id: String, visibility: com.zenith.launcher.data.model.WidgetVisibility): Boolean = when (id) {
    WidgetIds.DEADLINES -> visibility.deadlinesEnabled
    WidgetIds.FOCUS_MODE -> visibility.focusModeEnabled
    WidgetIds.POMODORO -> visibility.pomodoroEnabled
    WidgetIds.TODO -> visibility.todoEnabled
    WidgetIds.BACKLOG -> visibility.backlogEnabled
    WidgetIds.LIBRARY -> visibility.libraryEnabled
    WidgetIds.TARGETS -> visibility.targetsEnabled
    WidgetIds.APP_SHORTCUTS -> visibility.appShortcutsEnabled
    WidgetIds.SYSTEM_STATUS -> visibility.systemStatusEnabled
    else -> false
}

@Composable
private fun WidgetForId(
    id: String,
    state: HomeUiState,
    viewModel: HomeViewModel,
    onShowAddTodo: () -> Unit,
    onShowAddBacklog: () -> Unit,
    onShowAddLibrary: () -> Unit,
    onFocusToggle: () -> Unit = {},
    onPomodoroRunningChanged: (Boolean) -> Unit = {},
    onPomodoroProtectionChanged: (Boolean) -> Unit = {},
    onPomodoroPauseChanged: (Boolean, Int, String) -> Unit = { _, _, _ -> }
) {
    when (id) {
        WidgetIds.DEADLINES -> DeadlinesWidget(state.deadlineCountdowns)
        WidgetIds.FOCUS_MODE -> FocusModeToggle(state.isFocusModeActive, onFocusToggle)
        WidgetIds.POMODORO -> PomodoroWidget(
            onPomodoroRunningChanged = onPomodoroRunningChanged,
            onPomodoroProtectionChanged = onPomodoroProtectionChanged,
            onPomodoroPauseChanged = onPomodoroPauseChanged
        )
        WidgetIds.TODO -> TodoWidget(
            items = state.todoItems,
            onAddClick = onShowAddTodo,
            onToggle = viewModel::toggleTodo,
            onDelete = viewModel::deleteTodo
        )
        WidgetIds.BACKLOG -> BacklogWidget(
            items = state.backlogItems,
            onAddClick = onShowAddBacklog,
            onDelete = viewModel::deleteBacklogItem
        )
        WidgetIds.LIBRARY -> LibraryWidget(
            links = state.libraryLinks,
            onAddClick = onShowAddLibrary,
            onDelete = viewModel::deleteLibraryLink
        )
        WidgetIds.TARGETS -> TargetsWidget(
            targets = state.studyTargets,
            onAdd = viewModel::addStudyTarget,
            onChange = viewModel::updateStudyTarget,
            onDelete = viewModel::deleteStudyTarget
        )
        WidgetIds.APP_SHORTCUTS -> AppShortcutsWidget(
            pinnedApps = state.appShortcuts,
            allApps = state.apps,
            onLaunch = viewModel::launchApp,
            onPin = viewModel::addAppShortcut,
            onUnpin = viewModel::removeAppShortcut
        )
        WidgetIds.SYSTEM_STATUS -> SystemStatusWidget()
    }
}

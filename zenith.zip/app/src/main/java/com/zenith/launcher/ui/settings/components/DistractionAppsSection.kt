package com.zenith.launcher.ui.settings.components
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zenith.launcher.data.model.AppInfo


/** User-managed list of apps that Zenith treats as distractions before launch. */
@Composable
fun DistractionAppsSection(
    apps: List<AppInfo>,
    distractionPackages: Set<String>,
    onToggleApp: (String) -> Unit,
    showCard: Boolean = true
) {
    var query by remember { mutableStateOf("") }
    val filteredApps = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    val content: @Composable ColumnScope.() -> Unit = {
        Text(
            "Choose apps that tend to pull your attention away. Zenith inserts a brief reflection before launch.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search apps") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
            items(filteredApps, key = { it.packageName + it.activityClassName }) { app ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(app.label, style = MaterialTheme.typography.bodyMedium)
                    Checkbox(
                        checked = app.packageName in distractionPackages,
                        onCheckedChange = { onToggleApp(app.packageName) }
                    )
                }
            }
        }
    }
    if (showCard) {
        SettingsSectionCard(title = "Distraction apps", content = content)
    } else {
        Column(content = content)
    }
}
